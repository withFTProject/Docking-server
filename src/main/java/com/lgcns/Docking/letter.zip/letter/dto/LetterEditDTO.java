package com.lgcns.Docking.letter.dto;

import lombok.Getter;

@Getter
public class LetterEditDTO {
    private String title;
    private String description;
}