package com.lgcns.Docking.letter.dto;

import lombok.Getter;

@Getter
public class LetterCreateDTO {
    private String title;
    private String description;
}