package com.lgcns.Docking.letter.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class LetterReadResponseDTO {
    private String title;
    private String description;
    private String createdBy;
}
